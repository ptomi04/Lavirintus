﻿open System
open System.IO
open System.Windows
open System.Windows.Controls
open System.Windows.Media
open System.Windows.Media.Imaging
open System.Windows.Shapes


[<STAThread>]
[<EntryPoint>]
let main argv=
    //változók
    let map = Array2D.zeroCreate<int> 100 100    
    let mutable sor = ""
    //player változók
    
    let fokToRad rad = rad * System.Math.PI / 180.0

    let mutable lszog = 160

    let mutable px = 3.0
    let mutable py = 50.0
    let mutable pszog = 0.0
    let mutable prad = 0.0

    let mutable megye = false
    //Raycast változók

    //


    //
    let canvas = Canvas()
    
    
    let main_window = Window()
    main_window.Title <- "Labirintus 3D"
    main_window.Visibility <- Visibility.Visible
    main_window.Width <- 1920
    main_window.Height <- 1080
    main_window.WindowStyle <- WindowStyle.None
    let imageUri = System.Uri("hatter.png", System.UriKind.Relative)
    let image = BitmapImage(imageUri)
    let brush = ImageBrush(image)
    main_window.WindowState <- WindowState.Maximized
    main_window.Background <- brush
    //main_window.Topmost <- true
    
    main_window.Content <- canvas
    let app = Application()
    app.MainWindow <- main_window

    main_window.PreviewKeyDown.Add(fun args ->
    if args.Key = Input.Key.Escape then
      main_window.Close()
    )
    
    
    //---------------------------------------------

    //pálya
    use olvaso = new StreamReader("palya.txt")

    for y in  0.. 99 do
      sor <- olvaso.ReadLine()
      for x in 0 .. 98 do   
        map.[y,x] <- int sor[x] - int '0'
    
    
    for y in 0 .. 99 do
        for x in 0 .. 99 do
          let tkep = Rectangle()
          tkep.Width <- 10.0
          tkep.Height <- 10.0

          if map.[y, x] = 3 then
            px <- float (x*10)
            py <- float ((y*10)+10)
            

          Canvas.SetLeft(tkep, float x * 10.0)
          Canvas.SetTop(tkep, float y * 10.0)

          canvas.Children.Add(tkep) |> ignore
    

    //Raycast
    let mutable rays : Line list = []
  
    let rk (jx,jy, jszog, latoszog: int): unit =
        
        for ray in rays do
            canvas.Children.Remove(ray) |> ignore
        rays <- []
        

        let mutable a =0.0
        let mutable b =0.0
        let mutable tav =0.0

        let mutable rx = 3.0
        let mutable ry = 50.0
        let mutable rszog = 0.0
        let mutable rrad = 0.0
        let mutable lsz = 0.0
        let mutable i = 0
        // fal változók
        let mutable fx = 960  //kép kezdeti pozícciója
        let mutable fy = 540
        let mutable megjelmag = 0.0
        let falmag = 1080

        let mutable regi_rx = rx
        let mutable regi_ry = ry

        let mutable horizontale = false

        let mutable mx = 0.0

        //lsz <- fokToRad(latoszog)


        

        for i in -latoszog/2 .. latoszog / 2 do
          rx <- jx
          ry <- jy
          lsz <- fokToRad(i)

          while (map[int (ry/10.0),int (rx/10.0)] = 0) || (map[int (ry/10.0),int (rx/10.0)] = 3) do
            
            regi_rx <- rx
            regi_ry <- ry
            
            rrad <- fokToRad (jszog)+lsz
            rx <- rx + 5.0 * cos rrad
            ry <- ry + 5.0 * sin rrad


            if map[int (ry/10.0),int (rx/10.0)] = 2 then
                horizontale <- true   
            elif map[int (ry/10.0),int (rx/10.0)] = 1 then
                horizontale <- false 


          a<- abs (rx-jx)
          b<- abs (ry-jy)

          let halszemkorrekcio = fokToRad (float i)  // i = sugárszög eltérés
          tav <- sqrt((a*a)+(b*b)) * cos halszemkorrekcio

//------------3D fal------------
                     
          megjelmag <- float(falmag) * 100.0 / tav

          if megjelmag > falmag then
              megjelmag <- falmag

          mx <- float(fx + i*20 + latoszog / 2)

          let szin = if horizontale then Brushes.Gray else Brushes.DarkGray                           
          let newLine = Line(X1 = mx, Y1 = float fy + megjelmag/2.0, X2 = mx, Y2 = float fy - megjelmag/2.0,
                   Stroke = szin,
                   StrokeThickness = 20.0)        

          canvas.Children.Add(newLine) |> ignore
          rays <- newLine :: rays
          


 //-------------------------         


    
    
   //player

    let player = new Image()
    let bitmap = new BitmapImage(new Uri("player.png", UriKind.Relative))
    player.Source <- bitmap
    player.Width <- 20.0
    player.Height <- 20.0
    Canvas.SetLeft(player, px+20.0)
    Canvas.SetTop(player, py-10.0)
    canvas.Children.Add(player) |> ignore
    
    
    rk (px,py,pszog, lszog)
      
    
    

    //let x = Canvas.GetLeft(myRectangle)
    //let y = Canvas.GetTop(myRectangle)
    player.RenderTransformOrigin <- Point(0.5, 0.5)
    let rotate = new RotateTransform(0.0)
    player.RenderTransform <- rotate


    main_window.PreviewKeyDown.Add(fun args ->
    if args.Key = Input.Key.W then
        pszog <- rotate.Angle        
        if (map[int (py/10.0),int (px/10.0)+1] = 0) || (map[int (py/10.0),int (px/10.0)+1] = 3) then
            prad <- fokToRad pszog
            px <- px + 5.0 * cos prad
            py <- py + 5.0 * sin prad
            
            Canvas.SetTop(player, py-10.0)
            Canvas.SetTop(player, py-10.0)
            
        else
            px <- px - 10.0 * cos prad
            py <- py - 10.0 * sin prad
            
            Canvas.SetTop(player, py-10.0)
            Canvas.SetLeft(player, px-10.0)
        rk (px,py,pszog, lszog)
                   
    )

    main_window.PreviewKeyDown.Add(fun args ->
    if args.Key = Input.Key.S then
        pszog <- rotate.Angle
        if (map[int (py/10.0),int (px/10.0)-1] = 0) || (map[int (py/10.0),int (px/10.0)-1] = 3) then
            prad <- fokToRad pszog
            px <- px - 5.0 * cos prad
            py <- py - 5.0 * sin prad
            Canvas.SetTop(player, py-10.0)
            Canvas.SetLeft(player, px-10.0)
            rk (px,py,pszog, lszog)
        else
            prad <- fokToRad pszog
            px <- px + 10.0 * cos prad
            py <- py + 10.0 * sin prad

            Canvas.SetTop(player, py-10.0)
            Canvas.SetLeft(player, px-10.0)
        rk (px,py,pszog, lszog)
    )

    main_window.PreviewKeyDown.Add(fun args ->
    if args.Key = Input.Key.A then
        pszog <- (pszog - 5.0)

        if pszog < 0 then
            pszog <- 360
        rotate.Angle <- pszog
        rk (px,py,pszog, lszog)
    )

    main_window.PreviewKeyDown.Add(fun args ->
    if args.Key = Input.Key.D then
        pszog <- (pszog + 5.0)
        if pszog > 360 then
            pszog <- 0
        rotate.Angle <- pszog
        rk (px,py,pszog, lszog)
    )

    
   
    app.Run(main_window)